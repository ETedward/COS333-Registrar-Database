<?php

//----------------------------------------------------------------------
// order.php
// Author: Bob Dondero
//----------------------------------------------------------------------

define("DATABASE_NAME", "bookstore.sqlite");

function main($argc, $argv)
{   
   if ($argc != 3)
   {
      echo "Usage: php order.php isbn custid\n";
      exit(1);
   }
   
   $isbn = $argv[1];
   $custid = $argv[2];
   
   if (! file_exists(DATABASE_NAME))
      throw new Exception("Database connection failed");
   
   $db = new SQLite3(DATABASE_NAME);
      
   $stmtStr = "UPDATE orders SET quantity = quantity+1 " .
      "WHERE isbn = '" . $isbn . "' AND custid = '" . $custid . "'";
   $result = $db->query($stmtStr);

   $db->close();
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main($argc, $argv)

?>
