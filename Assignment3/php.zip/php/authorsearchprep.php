<?php

//----------------------------------------------------------------------
// authorsearchprep.php
// Author: Bob Dondero
//----------------------------------------------------------------------

define("DATABASE_NAME", "bookstore.sqlite");

function main($argv, $argc)
{
   if ($argc != 2)
   {
      echo "Usage: php authorsearchprep.php author\n";
      exit(1);
   }
   
   $author = $argv[1];
      
   if (! file_exists(DATABASE_NAME))
      throw new Exception("Database connection failed");

   $db = new SQLite3(DATABASE_NAME);

   $stmtStr = "SELECT books.isbn, title, quantity " .
      "FROM books, authors " .
      "WHERE books.isbn = authors.isbn " .
      "AND author = :author";  
   $statement = $db->prepare($stmtStr);
   $statement->bindValue(":author", $author, SQLITE3_TEXT);
      // Other types: SQLITE3_INTEGER, SQLITE3_FLOAT, SQLITE3_BLOB,
      // SQLITE3_NULL  
   $result = $statement->execute();
   
   while (($row = $result->fetchArray()) != null)
   {
      echo "ISBN: ". $row["isbn"] . "\n";
      echo "Title: " . $row["title"] . "\n";
      echo "Quantity: " . $row["quantity"] . "\n";
      echo "\n";
   }

   $db->close();
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main($argv, $argc)

?>
