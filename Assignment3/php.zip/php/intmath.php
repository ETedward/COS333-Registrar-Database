<?php

//----------------------------------------------------------------------
// intmath.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function gcd($i, $j)
{
   if (($i == 0) && ($j == 0))
      throw new DomainException();
   $i = abs($i);
   $j = abs($j);
   while ($j != 0)  // Euclid's algorithm
   {

      $temp = $i % $j;
      $i = $j;
      $j = $temp;
   }
   return $i;
}

function lcm($i, $j)
{
   if (($i == 0) || ($j == 0))
      throw new DomainException();
   $i = abs($i);
   $j = abs($j);
   return ($i / gcd($i, $j)) * $j;
}

?>
