<?php

//----------------------------------------------------------------------
// concord.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function processLine($line, &$concordance)
{
   $line = strtolower($line);
   preg_match_all('{[a-z]+}', $line, $words);

   foreach ($words[0] as $word)
   {  
      // echo "<$word>\n";    // For debugging.
      if (isset($concordance[$word]))
         $concordance[$word]++;
      else
         $concordance[$word] = 1;
   }
}

//----------------------------------------------------------------------

function main($argc, $argv)
{
   if ($argc != 2)
   {
      echo "Usage: $argv[0] file\n";
      exit(1);
   }
   
   $file = fopen($argv[1], "r");
   
   $concordance = array();
   while (($line = fgets($file)) != null)
      processLine($line, $concordance);
      
   fclose($file);
   
   foreach ($concordance as $word => $count)
      echo "$word: $count\n";
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main($argc, $argv);

?>
