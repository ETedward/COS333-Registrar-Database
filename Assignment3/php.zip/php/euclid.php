<?php

//----------------------------------------------------------------------
// euclid.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function gcd($i, $j)
{
   if (($i == 0) && ($j == 0))
      throw new DomainException();
   $i = abs($i);
   $j = abs($j);
   while ($j != 0)  // Euclid's algorithm
   {

      $temp = $i % $j;
      $i = $j;
      $j = $temp;
   }
   return $i;
}

function lcm($i, $j)
{
   if (($i == 0) || ($j == 0))
      throw new DomainException();
   $i = abs($i);
   $j = abs($j);
   return ($i / gcd($i, $j)) * $j;
}

function main()
{
   try
   {
      echo "Enter the first integer:\n";
      if (fscanf(STDIN, "%d", $i) != 1)
      {  
         fprintf(STDERR, "Error: Not a number.\n");
         exit(1);
      }
      
      echo "Enter the second integer:\n";
      if (fscanf(STDIN, "%d", $j) != 1)
      {  
         fprintf(STDERR, "Error: Not a number.\n");
         exit(1);
      }   
      
      $gcd = gcd($i, $j);
      echo "gcd: $gcd\n";

      $lcm = lcm($i, $j);
      echo "lcm: $lcm\n";
   }
   
   catch (DomainException $e)
   {
      fprintf(STDERR, "Error: Computation is undefined\n");
   }
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main()

?>
