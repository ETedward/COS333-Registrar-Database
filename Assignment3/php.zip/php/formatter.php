<?php

//----------------------------------------------------------------------
// formatter.php
// Author: Bob Dondero
//----------------------------------------------------------------------

define("CHARS_PER_LINE", 60);

function main($argc, $argv)
{

   if ($argc != 2)
   {
      echo "Usage: $argv[0] file\n";
      exit(1);
   }
   
   $file = fopen($argv[1], "r");

   $outLine = "";
   while (($inLine = fgets($file)) != null)
   {  
      preg_match_all('[\S+]', $inLine, $words);
      foreach ($words[0] as $word)
      {  
         if (strlen($outLine) + strlen($word) > CHARS_PER_LINE)
         {  
            echo rtrim($outLine, " ") . "\n";
            $outLine = "";
         }
         $outLine .= $word . " ";
      }
   }
   if ($outLine != "")
      echo rtrim($outLine, " ") . "\n";
      
   fclose($file);
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main($argc, $argv);

?>
