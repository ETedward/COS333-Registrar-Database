<?php

//----------------------------------------------------------------------
// fraction.php
// Author: Bob Dondero
//----------------------------------------------------------------------

require_once "intmath.php";

class Fraction
{
   private $num;
   private $den;

   private function normalize()
   {
      if ($this->den < 0)
      {
         $this->num *= -1;
         $this->den *= -1;
      }
      if ($this->num == 0)
         $this->den = 1;
      else
      {
         $gcden = gcd($this->num, $this->den);
         $this->num /= $gcden;
         $this->den /= $gcden;
      }
   }

   public function __construct($num = 0, $den = 1)
   {
      if ($den == 0)
         throw new Exception("Denominator cannot be 0");
      $this->num = $num;
      $this->den = $den;
      $this->normalize();
   }

   public function toString()
   {
      return $this->num . "/" . $this->den;
   }

   public function add($f)
   {
      $newNum = ($this->num * $f->den) + ($f->num * $this->den);
      $newDen = $this->den * $f->den;
      return new Fraction($newNum, $newDen);
   }

   public function sub($f)
   {
      $newNum = ($this->num * $f->den) - ($f->num * $this->den);
      $newDen = $this->den * $f->den;
      return new Fraction($newNum, $newDen);
   }

   public function mul($f)
   {
      $newNum = $this->num * $f->num;
      $newDen = $this->den * $f->den;
      return new Fraction($newNum, $newDen);
   }

   public function div($f)
   {
      $newNum = $this->num * $f->den;
      $newDen = $this->den * $f->num;
      return new Fraction($newNum, $newDen);
   }
}

//----------------------------------------------------------------------

// For testing:

function main()
{
   echo "Numerator 1: ";
   if (fscanf(STDIN, "%d", $n1) != 1)
   {  
      fprintf(STDERR, "Error: Not a number.\n");
      exit(1);
   }

   echo "Denominator 1: ";
   if (fscanf(STDIN, "%d", $d1) != 1)
   {  
      fprintf(STDERR, "Error: Not a number.\n");
      exit(1);
   }

   echo "Numerator 2: ";
   if (fscanf(STDIN, "%d", $n2) != 1)
   {  
      fprintf(STDERR, "Error: Not a number.\n");
      exit(1);
   }

   echo "Denominator 2: ";
   if (fscanf(STDIN, "%d", $d2) != 1)
   {  
      fprintf(STDERR, "Error: Not a number.\n");
      exit(1);
   }

   $f1 = new Fraction($n1, $d1);
   echo "f1: " . $f1->toString() . "\n";

   $f2 = new Fraction($n2, $d2);
   echo "f2: " . $f2->toString() . "\n";
   
   $f3 = $f1->add($f2);
   echo "f1 + f2: " . $f3->toString() . "\n";

   $f3 = $f1->sub($f2);
   echo "f1 - f2: " . $f3->toString() . "\n";

   $f3 = $f1->mul($f2);
   echo "f1 * f2: " . $f3->toString() . "\n";

   $f3 = $f1->div($f2);
   echo "f1 / f2: " . $f3->toString() . "\n";

   $f4 = new Fraction(1);
   echo $f4->toString() . "\n";

   $f5 = new Fraction();
   echo $f5->toString() . "\n";

   try
   {  
      $f6 = new Fraction(1, 0);
   }
   catch (Exception $e)
   {  
      echo $e->getMessage() . "\n";
   }

   $f7 = $f1;
   echo "f7: " . $f7->toString() . "\n";
   
   $f8 = clone($f1);
   echo "f4: " . $f8->toString() . "\n";
   
   if ($f1 == $f7)
      echo "f1 equals f7\n";
   if ($f1 == $f8)
      echo "f1 equals f8\n";      
   
   if ($f1 === $f7)
      echo "f1 is identical to f7\n";
   if ($f1 === $f8)
      echo "f1 is identical to f8\n"; 
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main()

?>
