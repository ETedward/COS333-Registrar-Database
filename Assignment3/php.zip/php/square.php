<?php

//----------------------------------------------------------------------
// square.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function sqr($i)
{
   return $i * $i;
}

function main()
{
   echo sqr(5) . "\n";
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main();

?>
