<?php

//----------------------------------------------------------------------
// authorsearch.php
// Author: Bob Dondero
//----------------------------------------------------------------------

define("DATABASE_NAME", "bookstore.sqlite");

function main($argc, $argv)
{   
   if ($argc != 2)
   {
      echo "Usage: php authorsearch.php author\n";
      exit(1);
   }
   
   $author = $argv[1];
   
   if (! file_exists(DATABASE_NAME))
      throw new Exception("Database connection failed");
   
   $db = new SQLite3(DATABASE_NAME);
      
   $stmtStr = "SELECT books.isbn, title, quantity " .
      "FROM books, authors " .
      "WHERE books.isbn = authors.isbn " .
      "AND author = '" . $author . "'"; 
   $result = $db->query($stmtStr);

   while (($row = $result->fetchArray()) != null)
   {  
      echo "ISBN: " . $row["isbn"] . "\n";
      echo "Title: " . $row["title"] . "\n";
      echo "Quantity: " . $row["quantity"] . "\n";
      echo "\n";
   }

   $db->close();
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main($argc, $argv)

?>
