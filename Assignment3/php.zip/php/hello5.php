#!/usr/bin/env php
<?php
//----------------------------------------------------------------------
// hello5.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function main()
{
   echo "hello, world\n";
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main();
?>
