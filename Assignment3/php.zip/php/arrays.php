<?php

//----------------------------------------------------------------------
// arrays.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function writeArray($a)
{
   foreach ($a as $element)
      echo $element . " ";
   echo "\n";
}

function appendBad($a) 
{
   $a[] = "green";
   $a[] = "blue";
   $a[] = "violet";
}

function append(&$a)
{ 
   $a[] = "green";
   $a[] = "blue";
   $a[] = "violet";
}
   
function main()
{
   $a = array("red", "orange", "yellow");
   echo "a: ";
   writeArray($a);  // Writes red orange yellow.

   $b = $a;         // b is a distinct copy of a.
   $b[] = "green";  // Affects b, but not a.
   echo "a: ";
   writeArray($a);  // Writes red orange yellow.
   echo "b: ";
   writeArray($b);  // Writes red orange yellow green.

   appendBad($a);   // a is unaffected.
   echo "a: ";
   writeArray($a);  // Writes red orange yellow.
   
   append($a);      // a is affected.
   echo "a: ";
   writearray($a);  // Writes red orange yellow green blue violet.
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main()

?>
