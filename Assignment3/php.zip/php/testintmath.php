<?php

//----------------------------------------------------------------------
// testintmath.php
// Author: Bob Dondero
//----------------------------------------------------------------------

require_once "intmath.php";

function main()
{
   try
   {
      echo "Enter the first integer:\n";
      if (fscanf(STDIN, "%d", $i) != 1)
      {  
         fprintf(STDERR, "Error: Not a number.\n");
         exit(1);
      }
      
      echo "Enter the second integer:\n";
      if (fscanf(STDIN, "%d", $j) != 1)
      {  
         fprintf(STDERR, "Error: Not a number.\n");
         exit(1);
      }   
      
      $gcd = gcd($i, $j);
      echo "gcd: $gcd\n";

      $lcm = lcm($i, $j);
      echo "lcm: $lcm\n";
   }
   
   catch (DomainException $e)
   {
      fprintf(STDERR, "Error: Computation is undefined\n");
   }
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main()

?>
