<?php

//----------------------------------------------------------------------
// linesort.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function main($argc, $argv)
{
   if ($argc != 2)
   {
      echo "Usage: $argv[0] file\n";
      exit(1);
   }
   
   $file = fopen($argv[1], "r");
   
   $lines = array();
   while (($line = fgets($file)) != null)
   {  
      $line = rtrim($line, "\n");
      $lines[] = $line;  // Appends.
   }
   
   fclose($file);

   sort($lines);

   foreach ($lines as $line)
      echo $line . "\n";
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main($argc, $argv)

?>
