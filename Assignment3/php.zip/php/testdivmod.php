<?php

//----------------------------------------------------------------------
// testdivmod.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function divmod($dividend, $divisor, &$remainder)
{
   $remainder = $dividend % $divisor;
   return (int)($dividend / $divisor);
}

function main()
{
   $quo = 0;
   $rem = 0;
   
   $quo = divmod(11, 3, $rem);
   echo "Quotient: $quo  Remainder: $rem\n";

   return 0;
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main();

?>
