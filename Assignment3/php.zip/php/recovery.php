<?php

//----------------------------------------------------------------------
// recovery.php
// Author: Bob Dondero
//----------------------------------------------------------------------

define("DATABASE_NAME", "bookstore.sqlite");

function main()
{
   if (! file_exists(DATABASE_NAME))
      throw new Exception("Database connection failed");
   
   $db = new SQLite3(DATABASE_NAME);

   for ($i = 0; $i < 200; $i++)
   {
      try
      {
         $db->exec('BEGIN;');

         $result = $db->query(
            "UPDATE orders SET quantity = quantity+1 " .
            "WHERE isbn = 123 AND custid = 222");
         if ($result == null)
         {   
            $db->exec('ROLLBACK;');
            echo "Transaction " . $i . " rolled back\n";
            exit();
         }
      
         if (rand(0, 49) == 0) 
            throw new Exception("Simulated error with i = " . $i ."\n");

         $result = $db->query(
            "UPDATE books SET quantity = quantity-1 WHERE isbn = 123");
         if ($result == null)
         {   
            $db->exec('ROLLBACK;');
            echo "Transaction " . $i . " rolled back\n";
            exit();
         }

         $db->exec('COMMIT;');
         echo "Transaction " . $i . " committed\n";
      }
      catch (Exception $e)
      {
         echo $e->getMessage();
         $db->exec('ROLLBACK;');
         echo "Transaction " . $i . " rolled back\n";
      }      
   }

   $db->close();
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main()

?>
