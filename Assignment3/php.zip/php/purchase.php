<?php

//----------------------------------------------------------------------
// purchase.php
// Author: Bob Dondero
//----------------------------------------------------------------------

define("DATABASE_NAME", "bookstore.sqlite");

function main($argc, $argv)
{   
   if ($argc != 3)
   {
      echo "Usage: php authorsearch.php isbn custid\n";
      exit(1);
   }
   
   $isbn = $argv[1];
   $custid = $argv[2]; 
      
   if (! file_exists(DATABASE_NAME))
      throw new Exception("Database connection failed");
   
   $db = new SQLite3(DATABASE_NAME);
      
   $db->exec('BEGIN;');

   $stmtStr = "UPDATE orders SET quantity = quantity+1 " .
      "WHERE isbn = :isbn AND custid = :custid";
      
   $statement = $db->prepare($stmtStr);
   $statement->bindValue(":isbn", $isbn, SQLITE3_TEXT);
   $statement->bindValue(":custid", $custid, SQLITE3_TEXT);
      // Other types: SQLITE3_INTEGER, SQLITE3_FLOAT, SQLITE3_BLOB,
      // SQLITE3_NULL
   
   $result = $statement->execute();
   if ($result == null)
   {   
      $db->exec('ROLLBACK;');
      echo "Transaction rolled back\n";
      exit();
   }

   $stmtStr = "UPDATE books SET quantity = quantity-1 " .
      "WHERE isbn = :isbn"; 
   $statement = $db->prepare($stmtStr);
   $statement->bindValue(":isbn", $isbn, SQLITE3_TEXT);
      // Other types: SQLITE3_INTEGER, SQLITE3_FLOAT, SQLITE3_BLOB,
      // SQLITE3_NULL
   $result = $statement->execute();
   if ($result == null)
   {
      $db->exec('ROLLBACK;');
      echo "Transaction rolled back\n";
      exit();
   }

   $db->exec('COMMIT;');
   echo "Transaction committed\n";

   $db->close();
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main($argc, $argv)

?>
