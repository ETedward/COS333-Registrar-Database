<?php

//----------------------------------------------------------------------
// circle.php
// Author: Bob Dondero
//----------------------------------------------------------------------

function main()
{
   echo "Enter the circle's radius:\n";

   if (fscanf(STDIN, "%d", $radius) != 1)
   {
      fprintf(STDERR, "Error: Not a number.\n");
      exit(1);
   }

   $diam = 2 * $radius;
   $circum = pi() * $diam;

   echo "A circle with radius $radius has diameter $diam\n";
   printf("and circumference %f.\n", $circum);
}

if (isset($argv[0]) && realpath($argv[0]) == realpath(__FILE__))
   main()

?>
